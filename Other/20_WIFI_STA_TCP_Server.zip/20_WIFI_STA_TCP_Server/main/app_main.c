/** 
 * @name		WIFI_STA_TCP_Server Example
 * @file		app_main.c 
 * @brief		用户应用程序入口
 * @details		用户应用程序的入口文件,用户所有要实现的功能逻辑均是从该文件开始或者处理
 * @author		路过人间 
 * @ver:        Ver0.0.1:路过人间, 2018/06/04, 初始化版本
*/
#include <stdio.h>
#include "esp_system.h"
#include "esp_spi_flash.h"
#include "esp_wifi.h"
#include "esp_event.h"
#include "esp_log.h"
#include "esp_err.h"
#include "nvs_flash.h"
#include "esp_event.h"
#include <string.h>
#include <sys/socket.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/event_groups.h"
#include "esp_wifi.h"
#include "driver/gpio.h"

static const char *TAG = "WIFI_STA_TCP_Server Demo";

/*

修改WIFI_SSID、WIFI_PAS为你家的WIFI
当开发板成功连接WIFI后会打印WIFI_STA_TCP_Client Demo: got ip:192.168.XXX.XXX
开发板按BOOT键开始创建TCP Server

打开电脑端网络助手
网络助手选择TCP Client 
服务器地址：输入开发板获取到的IP
远程主机端口：9527
电脑端发送数据，开发板会原样返回数据

*/

#define WIFI_SSID				"TP-YIXIN"			// WIFI 网络名称
#define WIFI_PAS				"a12345678"			// WIFI 密码
#define TCP_PORT				9527				// 监听客户端端口
#define LED_GPIO				4					// LED 连接的 GPIO端口


EventGroupHandle_t tcp_event_group;					// wifi建立成功信号量
//socket
static int server_socket = 0;						// 服务器socket
static struct sockaddr_in server_addr;				// server地址
static struct sockaddr_in client_addr;				// client地址
static unsigned int socklen = sizeof(client_addr);	// 地址长度
static int connect_socket = 0;						// 连接socket
bool g_rxtx_need_restart = false;					// 异常后，重新连接标记
// FreeRTOS event group to signal when we are connected to wifi
#define WIFI_CONNECTED_BIT							BIT0

void close_socket();// 关闭socket
void recv_data(void *pvParameters);// 接收数据任务
int get_socket_error_code(int socket);// 获取socket错误代码
int show_socket_error_reason(const char *str, int socket);// 获取socket错误原因
int check_working_socket();// 检查socket
void wifi_init_sta();// WIFI作为STA的初始化


// wifi 事件
static esp_err_t event_handler(void *ctx, system_event_t *event)
{
	switch (event->event_id)
	{
	case SYSTEM_EVENT_STA_START:        //STA模式-开始连接
		esp_wifi_connect();
		break;
	case SYSTEM_EVENT_STA_DISCONNECTED: //STA模式-断线
		esp_wifi_connect();
		xEventGroupClearBits(tcp_event_group, WIFI_CONNECTED_BIT);
		break;
	case SYSTEM_EVENT_STA_CONNECTED:    //STA模式-连接成功
		xEventGroupSetBits(tcp_event_group, WIFI_CONNECTED_BIT);
		break;
	case SYSTEM_EVENT_STA_GOT_IP:       //STA模式-获取IP
		ESP_LOGI(TAG, "got ip:%s\n",ip4addr_ntoa(&event->event_info.got_ip.ip_info.ip));xEventGroupSetBits(tcp_event_group, WIFI_CONNECTED_BIT);
		break;
	default:
		break;
	}
	return ESP_OK;
}



// 接收数据任务
void recv_data(void *pvParameters)
{
	int len = 0;
	char databuff[1024];
	while (1){
		memset(databuff, 0x00, sizeof(databuff));//清空缓存
		len = recv(connect_socket, databuff, sizeof(databuff), 0);//读取接收数据
		g_rxtx_need_restart = false;
		if (len > 0){
			ESP_LOGI(TAG, "recvData: %s", databuff);//打印接收到的数组
			send(connect_socket, databuff, strlen(databuff), 0);//接收数据回发
			//sendto(connect_socket, databuff , sizeof(databuff), 0, (struct sockaddr *) &remote_addr,sizeof(remote_addr));
		}else{
			show_socket_error_reason("recv_data", connect_socket);//打印错误信息
			g_rxtx_need_restart = true;//服务器故障，标记重连
			vTaskDelete(NULL);
		}
	}
	close_socket();
	g_rxtx_need_restart = true;//标记重连
	vTaskDelete(NULL);
}

// 建立tcp server
esp_err_t create_tcp_server(bool isCreatServer)
{
	//首次建立server
	if (isCreatServer){
		ESP_LOGI(TAG, "server socket....,port=%d", TCP_PORT);
		server_socket = socket(AF_INET, SOCK_STREAM, 0);//新建socket
		if (server_socket < 0){
			show_socket_error_reason("create_server", server_socket);
			close(server_socket);//新建失败后，关闭新建的socket，等待下次新建
			return ESP_FAIL;
		}
		//配置新建server socket参数
		server_addr.sin_family = AF_INET;
		server_addr.sin_port = htons(TCP_PORT);
		server_addr.sin_addr.s_addr = htonl(INADDR_ANY);
		//bind:地址的绑定
		if (bind(server_socket, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0){
			show_socket_error_reason("bind_server", server_socket);
			close(server_socket);//bind失败后，关闭新建的socket，等待下次新建
			return ESP_FAIL;
		}
	}
	//listen，下次时，直接监听
	if (listen(server_socket, 5) < 0){
		show_socket_error_reason("listen_server", server_socket);
		close(server_socket);//listen失败后，关闭新建的socket，等待下次新建
		return ESP_FAIL;
	}
	//accept，搜寻全连接队列
	connect_socket = accept(server_socket, (struct sockaddr *)&client_addr, &socklen);
	if (connect_socket < 0){
		show_socket_error_reason("accept_server", connect_socket);
		close(server_socket);//accept失败后，关闭新建的socket，等待下次新建
		return ESP_FAIL;
	}
	ESP_LOGI(TAG, "tcp connection established!");
	return ESP_OK;
}

// WIFI作为STA的初始化
void wifi_init_sta()
{
	tcp_event_group = xEventGroupCreate();
	tcpip_adapter_init();
	ESP_ERROR_CHECK(esp_event_loop_init(event_handler, NULL));
	wifi_init_config_t cfg = WIFI_INIT_CONFIG_DEFAULT();
	ESP_ERROR_CHECK(esp_wifi_init(&cfg));
	wifi_config_t wifi_config = {
		.sta = {
			.ssid = WIFI_SSID,
			.password = WIFI_PAS},
	};
	ESP_ERROR_CHECK(esp_wifi_set_mode(WIFI_MODE_STA));
	ESP_ERROR_CHECK(esp_wifi_set_config(ESP_IF_WIFI_STA, &wifi_config));
	ESP_ERROR_CHECK(esp_wifi_start());
	ESP_LOGI(TAG, "wifi_init_sta finished.");
	ESP_LOGI(TAG, "connect to ap SSID:%s password:%s \n",WIFI_SSID, WIFI_PAS);
}



// 获取socket错误代码
int get_socket_error_code(int socket)
{
	int result;
	u32_t optlen = sizeof(int);
	int err = getsockopt(socket, SOL_SOCKET, SO_ERROR, &result, &optlen);
	if (err == -1){
		//WSAGetLastError();
		ESP_LOGE(TAG, "socket error code:%d", err);
		ESP_LOGE(TAG, "socket error code:%s", strerror(err));
		return -1;
	}
	return result;
}

// 获取socket错误原因
int show_socket_error_reason(const char *str, int socket)
{
	int err = get_socket_error_code(socket);
	if (err != 0){
		ESP_LOGW(TAG, "%s socket error reason %d %s", str, err, strerror(err));
	}
	return err;
}
// 检查socket
int check_working_socket()
{
	int ret;
#if EXAMPLE_ESP_TCP_MODE_SERVER
	ESP_LOGD(TAG, "check server_socket");
	ret = get_socket_error_code(server_socket);
	if (ret != 0){
		ESP_LOGW(TAG, "server socket error %d %s", ret, strerror(ret));
	}
	if (ret == ECONNRESET){
		return ret;
	}
#endif
	ESP_LOGD(TAG, "check connect_socket");
	ret = get_socket_error_code(connect_socket);
	if (ret != 0){
		ESP_LOGW(TAG, "connect socket error %d %s", ret, strerror(ret));
	}
	if (ret != 0){
		return ret;
	}
	return 0;
}
// 关闭socket
void close_socket()
{
    close(connect_socket);
    close(server_socket);
}
// 建立TCP连接并从TCP接收数据
static void tcp_connect(void *pvParameters)
{
	while (1){
		g_rxtx_need_restart = false;
		// 等待WIFI连接信号量，死等
		xEventGroupWaitBits(tcp_event_group, WIFI_CONNECTED_BIT, false, true, portMAX_DELAY);
		ESP_LOGI(TAG, "start tcp connected");
		TaskHandle_t tx_rx_task = NULL;
		vTaskDelay(3000 / portTICK_RATE_MS);// 延时3S准备建立server
		ESP_LOGI(TAG, "create tcp server");
		int socket_ret = create_tcp_server(true);// 建立server
		if (socket_ret == ESP_FAIL){// 建立失败
			ESP_LOGI(TAG, "create tcp socket error,stop...");
			continue;
		}else{// 建立成功
			ESP_LOGI(TAG, "create tcp socket succeed...");            
			// 建立tcp接收数据任务
			if (pdPASS != xTaskCreate(&recv_data, "recv_data", 4096, NULL, 4, &tx_rx_task)){
				ESP_LOGI(TAG, "Recv task create fail!");
			}else{
				ESP_LOGI(TAG, "Recv task create succeed!");
			}
		}
		while (1){
			vTaskDelay(3000 / portTICK_RATE_MS);
			if (g_rxtx_need_restart){// 重新建立server，流程和上面一样
				ESP_LOGI(TAG, "tcp server error,some client leave,restart...");
				// 建立server
				if (ESP_FAIL != create_tcp_server(false)){
					if (pdPASS != xTaskCreate(&recv_data, "recv_data", 4096, NULL, 4, &tx_rx_task)){
						ESP_LOGE(TAG, "tcp server Recv task create fail!");
					}else{
						ESP_LOGI(TAG, "tcp server Recv task create succeed!");
						g_rxtx_need_restart = false;//重新建立完成，清除标记
					}
				}
			}
		}
	}
	vTaskDelete(NULL);
}


// 主函数
void app_main(void)
{
	ESP_LOGI(TAG, "APP Start......");
	//初始化flash
	esp_err_t ret = nvs_flash_init();
	if (ret == ESP_ERR_NVS_NO_FREE_PAGES){
		ESP_ERROR_CHECK(nvs_flash_erase());
		ret = nvs_flash_init();
	}
	ESP_ERROR_CHECK(ret);
	wifi_init_sta();// WIFI作为STA的初始化
	gpio_pad_select_gpio(LED_GPIO);// 选择要操作的GPIO
	gpio_set_direction(LED_GPIO, GPIO_MODE_OUTPUT);// 设置GPIO为推挽输出模式
	while(1){
		vTaskDelay(100 / portTICK_RATE_MS);
		if(gpio_get_level(0)==0){
			//新建一个tcp连接任务
			xTaskCreate(&tcp_connect, "tcp_connect", 4096, NULL, 5, NULL);
			break;
		}
	}
	while(1) {
		gpio_set_level(LED_GPIO, 0);// GPIO输出低
		vTaskDelay(500 / portTICK_PERIOD_MS);
		gpio_set_level(LED_GPIO, 1);// GPIO输出高
		vTaskDelay(500 / portTICK_PERIOD_MS);
	}
}