# Wifi SCAN Example

This example shows how to scan for available set of APs.

* The SCAN_LIST_SIZE parameter needs to be set from the example configuration menu. It represents maximum number of scan list entries that driver can populate.